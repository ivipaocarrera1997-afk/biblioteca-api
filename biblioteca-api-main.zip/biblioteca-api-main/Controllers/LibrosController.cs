using Microsoft.AspNetCore.Mvc;
using BibliotecaAPI.Models;

namespace BibliotecaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LibrosController : ControllerBase
    {
        // Lista en memoria
        private static List<Libro> libros = new List<Libro>
        {
            new Libro { Id = 1, Titulo = "Python para análisis de datos", Autor = "Wes McKinney", Disponible = true },
            new Libro { Id = 2, Titulo = "Aprendizaje automático práctico con Scikit-Learn, Keras y TensorFlow", Autor = "Aurélien Géron", Disponible = true },
            new Libro { Id = 3, Titulo = "Ciencia de datos desde cero", Autor = "Joel Grus", Disponible = false },
            new Libro { Id = 4, Titulo = "El libro de Machine Learning de cien páginas", Autor = "Andriy Burkov", Disponible = true }
        };

        [HttpGet]
        public ActionResult<IEnumerable<Libro>> Get()
        {
            return Ok(libros);
        }

        [HttpGet("{id}")]
        public ActionResult<Libro> GetById(int id)
        {
            var libro = libros.FirstOrDefault(l => l.Id == id);

            if (libro == null)
                return NotFound();

            return Ok(libro);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Libro nuevoLibro)
        {
            nuevoLibro.Id = libros.Count + 1;
            libros.Add(nuevoLibro);
            return Created("", nuevoLibro);
        }
    }
}