using Microsoft.AspNetCore.Mvc;
using BibliotecaAPI.Models;

namespace BibliotecaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriasController : ControllerBase
    {
        private static List<Categoria> categorias = new List<Categoria>
        {
           new Categoria { Id = 1, Nombre = "Ciencia de Datos" },
            new Categoria { Id = 2, Nombre = "Machine Learning" }
        };

        [HttpGet]
        public ActionResult<IEnumerable<Categoria>> Get()
        {
            return Ok(categorias);
        }
    }
}